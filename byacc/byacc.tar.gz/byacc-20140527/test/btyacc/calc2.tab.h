#ifndef _calc2__defines_h_
#define _calc2__defines_h_

#define DIGIT 257
#define LETTER 258
#define UMINUS 259

#endif /* _calc2__defines_h_ */
