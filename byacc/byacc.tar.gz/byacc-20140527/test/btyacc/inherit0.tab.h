#ifndef _inherit0__defines_h_
#define _inherit0__defines_h_

#define GLOBAL 257
#define LOCAL 258
#define REAL 259
#define INTEGER 260
#define NAME 261

#endif /* _inherit0__defines_h_ */
